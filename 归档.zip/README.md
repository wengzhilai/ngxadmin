问题:WARN tar ENOENT: no such file or directory, lstat
sudo npm cache clean -f
sudo npm install -g n
sudo n stable
以及，删除package-lock.json文件

npm uninstall -save @nebular/auth


npm install @ngx-translate/core --save
npm install @ngx-translate/http-loader --save
npm install ngx-bootstrap --save
npm install ngx-treeview --save


npm uninstall -save @ng-bootstrap/ng-bootstrap
.ion-chevron-left:before { content: "\f125"; }