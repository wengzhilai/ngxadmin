
export class PostBaseModel {
    constructor() {

    }
    /**
     * 主键
     */
    Key: string = ""

    Token: string = ""
    /**
     * 产品
     */
    LanguageCode: string = "Cn";
}