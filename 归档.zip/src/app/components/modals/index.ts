export { ModalConfirmPage } from "./confirm"
export { ModalLoadingPage } from "./loading"