import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-auth-register',
  templateUrl: './auth-register.component.html',
  styleUrls: ['./auth-register.component.scss']
})
export class AuthRegisterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
