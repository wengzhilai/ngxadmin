import { Component } from '@angular/core';

@Component({
  selector: 'app-auth-elements',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class AuthComponent {
}
